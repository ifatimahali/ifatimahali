# BLOG WEBSITE
This is my first blog webite made in Django framework.
